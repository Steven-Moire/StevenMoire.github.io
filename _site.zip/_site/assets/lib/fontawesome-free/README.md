# How to upgrade Fontawesome

Download [Fontawesome For The Web](https://fontawesome.com/download) and replace the target files.
